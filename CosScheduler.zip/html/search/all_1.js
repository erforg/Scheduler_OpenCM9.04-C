var searchData=
[
  ['buffer',['buffer',['../struct_cos_fifo__t.html#a20e50bc215ec8d0677d7cd39771aa566',1,'CosFifo_t']]]
];
