var searchData=
[
  ['maxslots',['maxSlots',['../struct_cos_fifo__t.html#a2905aa8d28792d894ac2bdfcf7c725ab',1,'CosFifo_t']]]
];
