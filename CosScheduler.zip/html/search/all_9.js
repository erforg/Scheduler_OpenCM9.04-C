var searchData=
[
  ['pdata',['pData',['../struct_cos_task__t.html#ae7fd59104b9a322db750414f626f4d62',1,'CosTask_t']]],
  ['platform_5farduino',['PLATFORM_ARDUINO',['../cos__configure_8h.html#a46f17a099f062ff480642518e50108c2',1,'cos_configure.h']]],
  ['platform_5fopen_5fcm_5f9_5f04',['PLATFORM_OPEN_CM_9_04',['../cos__configure_8h.html#ac2c0460188f09106cc473bb7300b9c26',1,'cos_configure.h']]],
  ['platform_5frenesas_5frx63n',['PLATFORM_RENESAS_RX63N',['../cos__configure_8h.html#a039ccc32dae40fe940ef260875fb093b',1,'cos_configure.h']]],
  ['prio',['prio',['../struct_cos_task__t.html#ab7f6dd7aa4d80948ceb4de44cd58bcd2',1,'CosTask_t']]],
  ['prio_5fbased_5fscheduling',['PRIO_BASED_SCHEDULING',['../cos__scheduler_8c.html#a7674f201bb1919bcfa67420335397076',1,'cos_scheduler.c']]]
];
