var searchData=
[
  ['rindex',['rIndex',['../struct_cos_fifo__t.html#a82e57874f08b7f50f187ca6a8ea0bb54',1,'CosFifo_t']]],
  ['root_5fpt',['root_pt',['../struct_cos_sema__t.html#a81a5e36403b344942ed715390ba5632e',1,'CosSema_t']]],
  ['rsema',['rSema',['../struct_cos_fifo__t.html#aca97e7ac4862fcdb23295d077ea76158',1,'CosFifo_t']]]
];
