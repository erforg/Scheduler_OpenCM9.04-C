var searchData=
[
  ['sergetc',['serGetc',['../cos__ser_8c.html#a4a0a387ad92a32983659963323227ef9',1,'serGetc(void):&#160;cos_ser.c'],['../cos__ser_8h.html#a4a0a387ad92a32983659963323227ef9',1,'serGetc(void):&#160;cos_ser.c']]],
  ['sergets',['serGets',['../cos__ser_8c.html#a250941525ce3013d659fe1f31439ec3c',1,'serGets(char *pt):&#160;cos_ser.c'],['../cos__ser_8h.html#a250941525ce3013d659fe1f31439ec3c',1,'serGets(char *pt):&#160;cos_ser.c']]],
  ['serinint16dec',['serInInt16Dec',['../cos__ser_8c.html#ae7ecd7c45aaafcd877b52a5196c2d859',1,'serInInt16Dec(int16_t *x):&#160;cos_ser.c'],['../cos__ser_8h.html#ae7ecd7c45aaafcd877b52a5196c2d859',1,'serInInt16Dec(int16_t *x):&#160;cos_ser.c']]],
  ['serinit',['serInit',['../cos__ser_8c.html#a10f47a525a0b674226109dabafde97f7',1,'serInit(uint32_t baudRate):&#160;cos_ser.c'],['../cos__ser_8h.html#a10f47a525a0b674226109dabafde97f7',1,'serInit(uint32_t baudRate):&#160;cos_ser.c']]],
  ['serinuint16dec',['serInUint16Dec',['../cos__ser_8c.html#aa0768513b2b115e6d1672618c0bf4b77',1,'serInUint16Dec(uint16_t *x):&#160;cos_ser.c'],['../cos__ser_8h.html#aa0768513b2b115e6d1672618c0bf4b77',1,'serInUint16Dec(uint16_t *x):&#160;cos_ser.c']]],
  ['serinuint16hex',['serInUint16Hex',['../cos__ser_8c.html#af940c5580c1c0351bd5c1a062056cf54',1,'serInUint16Hex(uint16_t *x):&#160;cos_ser.c'],['../cos__ser_8h.html#af940c5580c1c0351bd5c1a062056cf54',1,'serInUint16Hex(uint16_t *x):&#160;cos_ser.c']]],
  ['seroutint16dec',['serOutInt16Dec',['../cos__ser_8c.html#af77c7ff3e6a5520d9ce58f021d233173',1,'serOutInt16Dec(int16_t y):&#160;cos_ser.c'],['../cos__ser_8h.html#a44cdb5950ea96f661b1544b8ea1f8b0a',1,'serOutInt16Dec(int16_t x):&#160;cos_ser.c']]],
  ['seroutint32dec',['serOutInt32Dec',['../cos__ser_8c.html#a2408f23bb06643e61a73067d819be4bd',1,'serOutInt32Dec(int32_t y):&#160;cos_ser.c'],['../cos__ser_8h.html#a97df4470c620736db324637e490cacf9',1,'serOutInt32Dec(int32_t x):&#160;cos_ser.c']]],
  ['seroutuint16dec',['serOutUint16Dec',['../cos__ser_8c.html#aa025c1a1330cc84460eae6f77769381a',1,'serOutUint16Dec(uint16_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#aa025c1a1330cc84460eae6f77769381a',1,'serOutUint16Dec(uint16_t x):&#160;cos_ser.c']]],
  ['seroutuint16hex',['serOutUint16Hex',['../cos__ser_8c.html#aac51102275ec5b0b199e92ecff7a5d1a',1,'serOutUint16Hex(uint16_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#aac51102275ec5b0b199e92ecff7a5d1a',1,'serOutUint16Hex(uint16_t x):&#160;cos_ser.c']]],
  ['seroutuint32dec',['serOutUint32Dec',['../cos__ser_8c.html#a5f63ece336f7ddfaad593c8f256f19ad',1,'serOutUint32Dec(uint32_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#a5f63ece336f7ddfaad593c8f256f19ad',1,'serOutUint32Dec(uint32_t x):&#160;cos_ser.c']]],
  ['seroutuint32hex',['serOutUint32Hex',['../cos__ser_8c.html#aa5226e9ced6ea444a95575d4a503fd3f',1,'serOutUint32Hex(uint32_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#aa5226e9ced6ea444a95575d4a503fd3f',1,'serOutUint32Hex(uint32_t x):&#160;cos_ser.c']]],
  ['seroutuint8bin',['serOutUint8Bin',['../cos__ser_8c.html#a81118f04de982bca9454b909e4a04036',1,'serOutUint8Bin(uint8_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#a81118f04de982bca9454b909e4a04036',1,'serOutUint8Bin(uint8_t x):&#160;cos_ser.c']]],
  ['seroutuint8hex',['serOutUint8Hex',['../cos__ser_8c.html#ae9f022a62e1079e0829ae987ffc32b84',1,'serOutUint8Hex(uint8_t x):&#160;cos_ser.c'],['../cos__ser_8h.html#ae9f022a62e1079e0829ae987ffc32b84',1,'serOutUint8Hex(uint8_t x):&#160;cos_ser.c']]],
  ['serpollc',['serPollc',['../cos__ser_8c.html#a10630040a390863abdcfeeb1a6601c30',1,'serPollc(void):&#160;cos_ser.c'],['../cos__ser_8h.html#a10630040a390863abdcfeeb1a6601c30',1,'serPollc(void):&#160;cos_ser.c']]],
  ['serputc',['serPutc',['../cos__ser_8c.html#a0573b20b3e7032cc9b705c3e2c7b34ac',1,'serPutc(char x):&#160;cos_ser.c'],['../cos__ser_8h.html#a0573b20b3e7032cc9b705c3e2c7b34ac',1,'serPutc(char x):&#160;cos_ser.c']]],
  ['serputs',['serPuts',['../cos__ser_8c.html#a98c127e962fdf633ac53445e1d1b1499',1,'serPuts(char *pt):&#160;cos_ser.c'],['../cos__ser_8h.html#a98c127e962fdf633ac53445e1d1b1499',1,'serPuts(char *pt):&#160;cos_ser.c']]],
  ['set_5fbit',['set_bit',['../cos__systime_8h.html#a917345fa41f8c12752cd6decc026be6f',1,'cos_systime.h']]],
  ['sleeptime_5fticks',['sleepTime_Ticks',['../struct_cos_task__t.html#a09d092b50302e5a804a5401f22a74a94',1,'CosTask_t']]],
  ['slotsize',['slotSize',['../struct_cos_fifo__t.html#afb2ca93eb14d46adce18311abba7249f',1,'CosFifo_t']]],
  ['state',['state',['../struct_cos_task__t.html#a5f0cedbb824458eb32448df66c55532f',1,'CosTask_t']]]
];
