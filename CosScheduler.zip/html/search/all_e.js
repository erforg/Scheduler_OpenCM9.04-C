var searchData=
[
  ['windex',['wIndex',['../struct_cos_fifo__t.html#a091ecd637d679eadcd72a32b7ea4a8d3',1,'CosFifo_t']]],
  ['wsema',['wSema',['../struct_cos_fifo__t.html#a70f5392513569a0cad32bb98268b84df',1,'CosFifo_t']]]
];
