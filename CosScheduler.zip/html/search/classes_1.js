var searchData=
[
  ['node_5ft',['Node_t',['../struct_node__t.html',1,'']]]
];
