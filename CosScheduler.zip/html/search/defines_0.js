var searchData=
[
  ['clear_5fbit',['clear_bit',['../cos__systime_8h.html#a40642327be6503d80adb086e29dff18e',1,'cos_systime.h']]],
  ['cos_5ffifoblockingreadsingleslot',['COS_FifoBlockingReadSingleSlot',['../cos__data__fifo_8h.html#a332c912924fbd6febc471136a1ad9c57',1,'cos_data_fifo.h']]],
  ['cos_5ffifoblockingwritesingleslot',['COS_FifoBlockingWriteSingleSlot',['../cos__data__fifo_8h.html#a3aa405ebea08eadb46e24baaf8ad5d3e',1,'cos_data_fifo.h']]],
  ['cos_5fplatform',['COS_PLATFORM',['../cos__configure_8h.html#af4ee1c5da659e8ce87bc512715414031',1,'cos_configure.h']]],
  ['cos_5fsem_5fwait',['COS_SEM_WAIT',['../cos__semaphore_8h.html#a60300e4cadbdf3e9420a4f2b828833da',1,'cos_semaphore.h']]],
  ['cos_5ftask_5fbegin',['COS_TASK_BEGIN',['../cos__scheduler_8h.html#a3b13be45a4a2b1ba30227879a3f0243d',1,'cos_scheduler.h']]],
  ['cos_5ftask_5fend',['COS_TASK_END',['../cos__scheduler_8h.html#aa0dddbc4da857470dd6e8a05f6c1d8d4',1,'cos_scheduler.h']]],
  ['cos_5ftask_5fschedule',['COS_TASK_SCHEDULE',['../cos__scheduler_8h.html#a2a7054ba14a3501a33dfe1d7f19493be',1,'cos_scheduler.h']]],
  ['cos_5ftask_5fsleep',['COS_TASK_SLEEP',['../cos__scheduler_8h.html#ad808c0bbc3a897fa33e0a15f68d8e164',1,'cos_scheduler.h']]]
];
