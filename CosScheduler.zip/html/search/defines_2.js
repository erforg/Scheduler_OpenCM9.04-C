var searchData=
[
  ['idle_5ftask_5fperiod_5fticks',['IDLE_TASK_PERIOD_TICKS',['../cos__scheduler_8c.html#aa20a1ca32254557fd034c45958443e45',1,'cos_scheduler.c']]],
  ['idle_5ftask_5fprio',['IDLE_TASK_PRIO',['../cos__scheduler_8c.html#ae0e1669e1adcd89a2aedd8c503e5c76f',1,'cos_scheduler.c']]]
];
