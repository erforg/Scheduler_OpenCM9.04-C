var searchData=
[
  ['load_5fmeasure_5ftask_5fperiod_5fticks',['LOAD_MEASURE_TASK_PERIOD_TICKS',['../cos__scheduler_8c.html#a908df92c7a19349031a3bd1765ff2e27',1,'cos_scheduler.c']]],
  ['load_5fmeasure_5ftask_5fprio',['LOAD_MEASURE_TASK_PRIO',['../cos__scheduler_8c.html#a8e6f549b18c577d720038bcfd0623f01',1,'cos_scheduler.c']]]
];
