var indexSectionsWithContent =
{
  0: "_bcdfilmnprstuw",
  1: "cn",
  2: "c",
  3: "_cs",
  4: "bcfilmnprstuw",
  5: "cinu",
  6: "cdilnpst",
  7: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros",
  7: "Pages"
};

