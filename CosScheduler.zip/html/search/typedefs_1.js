var searchData=
[
  ['int16_5ft',['int16_t',['../cos__types_8h.html#aa343fa3b3d06292b959ffdd4c4703b06',1,'cos_types.h']]],
  ['int32_5ft',['int32_t',['../cos__types_8h.html#a32f2e37ee053cf2ce8ca28d1f74630e5',1,'cos_types.h']]],
  ['int64_5ft',['int64_t',['../cos__types_8h.html#a996e72f71b11a5bb8b3b7b6936b1516d',1,'cos_types.h']]],
  ['int8_5ft',['int8_t',['../cos__types_8h.html#ad566f6541e98b74246db1a3a3a85ad49',1,'cos_types.h']]]
];
