var searchData=
[
  ['isinitialized',['isInitialized',['../struct_cos_fifo__t.html#adadc7ea0cecfa56760eb47f95a9481f7',1,'CosFifo_t']]]
];
