var searchData=
[
  ['lastactivationtime_5fticks',['lastActivationTime_Ticks',['../struct_cos_task__t.html#aba654d4a89fbfd3a935687132ccd74b0',1,'CosTask_t']]],
  ['linecnt',['lineCnt',['../struct_cos_task__t.html#aae831cffad65ea7a07c106a103c7a798',1,'CosTask_t']]]
];
