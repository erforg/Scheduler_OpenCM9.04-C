var searchData=
[
  ['pdata',['pData',['../struct_cos_task__t.html#ae7fd59104b9a322db750414f626f4d62',1,'CosTask_t']]],
  ['prio',['prio',['../struct_cos_task__t.html#ab7f6dd7aa4d80948ceb4de44cd58bcd2',1,'CosTask_t']]]
];
