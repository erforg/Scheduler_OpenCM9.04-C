var searchData=
[
  ['sleeptime_5fticks',['sleepTime_Ticks',['../struct_cos_task__t.html#a09d092b50302e5a804a5401f22a74a94',1,'CosTask_t']]],
  ['slotsize',['slotSize',['../struct_cos_fifo__t.html#afb2ca93eb14d46adce18311abba7249f',1,'CosFifo_t']]],
  ['state',['state',['../struct_cos_task__t.html#a5f0cedbb824458eb32448df66c55532f',1,'CosTask_t']]]
];
