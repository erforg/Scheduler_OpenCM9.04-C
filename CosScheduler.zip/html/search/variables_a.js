var searchData=
[
  ['task_5fpt',['task_pt',['../struct_node__t.html#a95f1080a412ebcda32a806a4dc8e620c',1,'Node_t']]]
];
