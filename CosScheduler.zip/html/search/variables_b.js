var searchData=
[
  ['usedslots',['usedSlots',['../struct_cos_fifo__t.html#a492dc1672892a877779f284b6ffdb27d',1,'CosFifo_t']]]
];
