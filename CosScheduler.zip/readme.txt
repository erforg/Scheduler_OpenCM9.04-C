  Installation on openCM and Arduino
  ----------------------------------
  Please extract the files of the archive and copy them to your 'libraries'

  directory. After that, the 'libraries' directory should have this structure:

	
	libraries/

	    CosScheduler/

			examples/

			html/

			utility/	

	
  Restart the IDE.
  To view the documentation of COS, go to 'html' sub-directory and open 

  file 'index.html' in your browser.

  Please refer to the whitepaper in subdirectory libraries/CosScheduler/examples/ 
  for additional information on the example programs.

